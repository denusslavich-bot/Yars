package dev.tiffany.module;

public class FovModule extends Module {
    // Fixed FOV: ignores sprint / speed / bow FOV changes
    public final Setting fov = add("Fov", 30, 140, 90);

    public FovModule() { super("StaticFov", Category.RENDER); }

    public float apply(float vanilla) { return enabled ? (float) fov.value : vanilla; }
}

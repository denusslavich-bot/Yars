package dev.tiffany.module;

import dev.tiffany.Tiffany;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

public class TargetHudModule extends Module {
    private static final int W = 120, H = 32, PAD = 4, BAR_H = 4, OFFSET_X = 30, OFFSET_Y = 20;
    private static final int HOLD_TICKS = 40, COL_BAR_BG = 0xFF2A2A36, COL_HP = 0xFF44DD66;
    private static final float HP_SMOOTH = 0.15f;

    private LivingEntity target;
    private int hold;
    private float shownHp;

    public TargetHudModule() { super("TargetHUD", Category.HUD); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.crosshairTarget instanceof EntityHitResult r
                && r.getEntity() instanceof LivingEntity le && le != mc.player) {
            if (le != target) shownHp = le.getHealth();
            target = le; hold = HOLD_TICKS;
        } else if (hold > 0 && --hold == 0) {
            target = null;
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc) {
        if (target == null || !target.isAlive()) return;
        float max = Math.max(1f, target.getMaxHealth());
        shownHp += (target.getHealth() - shownHp) * HP_SMOOTH;
        int x = ctx.getScaledWindowWidth() / 2 + OFFSET_X;
        int y = ctx.getScaledWindowHeight() / 2 + OFFSET_Y;
        Draw.box(ctx, x, y, W, H, Tiffany.THEME.accent(1));
        ctx.drawText(mc.textRenderer, target.getName().getString(), x + PAD, y + PAD + 1, Draw.COL_TEXT, true);
        String hp = String.format("%.1f / %.1f", target.getHealth(), max);
        ctx.drawText(mc.textRenderer, hp, x + PAD, y + PAD + 11, Draw.COL_DIM, true);
        int by = y + H - BAR_H - PAD;
        int bw = W - PAD * 2;
        ctx.fill(x + PAD, by, x + PAD + bw, by + BAR_H, COL_BAR_BG);
        ctx.fill(x + PAD, by, x + PAD + (int) (bw * Math.min(1f, shownHp / max)), by + BAR_H, COL_HP);
    }
}

package dev.tiffany.gui;

import dev.tiffany.Tiffany;
import dev.tiffany.module.Category;
import dev.tiffany.module.Draw;
import dev.tiffany.module.Module;
import dev.tiffany.module.Setting;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class ClickGui extends Screen {
    // ===== CONFIG =====
    private static final int PANEL_W = 112, PANEL_GAP = 8, START_X = 16, START_Y = 16;
    private static final int HEADER_H = 18, ROW_H = 16, SET_H = 14;
    private static final float OPEN_MS = 220f;
    private static final int OPEN_SLIDE = 16, DIM_MAX_ALPHA = 0x70;
    private static final int COL_BG = 0xE0121218, COL_ON = 0xFF2A2A44, COL_OFF = 0xFF1A1A24;
    private static final int COL_HOVER = 0xFF242434, COL_SET_BG = 0xE00E0E14;
    // ==================

    private static final Category[] CATS = Category.values();
    private static final int[][] POS = new int[CATS.length][2];
    static {
        for (int i = 0; i < CATS.length; i++) {
            POS[i][0] = START_X + i * (PANEL_W + PANEL_GAP);
            POS[i][1] = START_Y;
        }
    }

    private final long openTime = System.currentTimeMillis();
    private Setting dragging;
    private int dragSliderX;
    private int dragPanel = -1;

    public ClickGui() { super(Text.literal("Tiffany")); }

    private static boolean hit(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my < y + h;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        float p = Math.min(1f, (System.currentTimeMillis() - openTime) / OPEN_MS);
        p = 1f - (1f - p) * (1f - p);
        ctx.fill(0, 0, width, height, ((int) (DIM_MAX_ALPHA * p)) << 24);
        int yShift = (int) ((1f - p) * -OPEN_SLIDE);

        for (int i = 0; i < CATS.length; i++) {
            int x = POS[i][0], y = POS[i][1] + yShift;
            int accent = Tiffany.THEME.accent(i * 3);
            ctx.fill(x, y, x + PANEL_W, y + HEADER_H, accent);
            ctx.drawText(textRenderer, CATS[i].label, x + 6, y + 5, 0xFF101018, false);
            y += HEADER_H;

            for (Module m : Tiffany.MODULES) {
                if (m.category != CATS[i]) continue;
                boolean hover = hit(mx, my, x, y, PANEL_W, ROW_H);
                ctx.fill(x, y, x + PANEL_W, y + ROW_H, m.enabled ? COL_ON : (hover ? COL_HOVER : COL_OFF));
                if (m.enabled) ctx.fill(x, y, x + 2, y + ROW_H, accent);
                ctx.drawText(textRenderer, m.name, x + 7, y + 4, m.enabled ? Draw.COL_TEXT : Draw.COL_DIM, true);
                if (!m.settings.isEmpty())
                    ctx.drawText(textRenderer, m.expanded ? "-" : "+", x + PANEL_W - 10, y + 4, Draw.COL_DIM, true);
                y += ROW_H;

                if (m.expanded) {
                    for (Setting s : m.settings) {
                        ctx.fill(x, y, x + PANEL_W, y + SET_H, COL_SET_BG);
                        double t = (s.value - s.min) / (s.max - s.min);
                        ctx.fill(x, y, x + (int) (PANEL_W * t), y + SET_H, Draw.alpha(accent, 0xA0));
                        ctx.drawText(textRenderer, s.name + ": " + String.format("%.1f", s.value),
                                x + 7, y + 3, Draw.COL_TEXT, true);
                        y += SET_H;
                    }
                }
            }
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();

        for (int i = 0; i < CATS.length; i++) {
            int x = POS[i][0], y = POS[i][1];
            if (btn == 0 && hit(mx, my, x, y, PANEL_W, HEADER_H)) { dragPanel = i; return true; }
            y += HEADER_H;

            for (Module m : Tiffany.MODULES) {
                if (m.category != CATS[i]) continue;
                if (hit(mx, my, x, y, PANEL_W, ROW_H)) {
                    if (btn == 0) m.enabled = !m.enabled;
                    else if (btn == 1) m.expanded = !m.expanded;
                    return true;
                }
                y += ROW_H;
                if (m.expanded) {
                    for (Setting s : m.settings) {
                        if (btn == 0 && hit(mx, my, x, y, PANEL_W, SET_H)) {
                            dragging = s; dragSliderX = x;
                            applySlider(mx);
                            return true;
                        }
                        y += SET_H;
                    }
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragging != null) { applySlider(click.x()); return true; }
        if (dragPanel >= 0) {
            POS[dragPanel][0] += (int) Math.round(offsetX);
            POS[dragPanel][1] += (int) Math.round(offsetY);
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        dragPanel = -1;
        return super.mouseReleased(click);
    }

    private void applySlider(double mx) {
        double t = Math.max(0, Math.min(1, (mx - dragSliderX) / PANEL_W));
        dragging.value = dragging.min + t * (dragging.max - dragging.min);
    }

    @Override
    public boolean shouldPause() { return false; }
}

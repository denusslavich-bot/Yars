package dev.tiffany.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class FullbrightModule extends Module {
    private static final int EFFECT_TICKS = 1000;
    private boolean applied;

    public FullbrightModule() { super("Fullbright", Category.RENDER); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.player == null) return;
        if (enabled) {
            mc.player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.NIGHT_VISION, EFFECT_TICKS, 0, false, false, false));
            applied = true;
        } else if (applied) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            applied = false;
        }
    }
}

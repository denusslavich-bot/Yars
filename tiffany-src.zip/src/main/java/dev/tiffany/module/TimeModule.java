package dev.tiffany.module;

import net.minecraft.client.MinecraftClient;

public class TimeModule extends Module {
    // 0 dawn, 6000 noon, 12000 sunset, 18000 midnight
    public final Setting time = add("Time", 0, 24000, 6000);

    public TimeModule() { super("Time", Category.WORLD); }

    @Override
    public void tick(MinecraftClient mc) {
        if (!enabled || mc.world == null) return;
        mc.world.getLevelProperties().setTimeOfDay((long) time.value);
    }
}

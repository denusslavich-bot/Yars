package dev.tiffany.module;

import dev.tiffany.Tiffany;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;

public class KeystrokesModule extends Module {
    private static final int BOX = 22, GAP = 2, SPACE_H = 14;
    private static final int COL_OFF = 0x90141418, ON_ALPHA = 0xD0;

    public final Setting posX = add("X", 0, 400, 10);
    public final Setting posY = add("Y", 0, 300, 150);

    public KeystrokesModule() { super("Keystrokes", Category.HUD); }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc) {
        int x = (int) posX.value, y = (int) posY.value;
        key(ctx, mc, "W", mc.options.forwardKey, x + BOX + GAP, y, BOX, BOX);
        key(ctx, mc, "A", mc.options.leftKey,    x,                  y + BOX + GAP, BOX, BOX);
        key(ctx, mc, "S", mc.options.backKey,    x + BOX + GAP,      y + BOX + GAP, BOX, BOX);
        key(ctx, mc, "D", mc.options.rightKey,   x + (BOX + GAP) * 2, y + BOX + GAP, BOX, BOX);
        key(ctx, mc, "SPACE", mc.options.jumpKey, x, y + (BOX + GAP) * 2, BOX * 3 + GAP * 2, SPACE_H);
    }

    private void key(DrawContext ctx, MinecraftClient mc, String label, KeyBinding k, int x, int y, int w, int h) {
        ctx.fill(x, y, x + w, y + h, k.isPressed() ? Draw.alpha(Tiffany.THEME.accent(0), ON_ALPHA) : COL_OFF);
        int tx = x + (w - mc.textRenderer.getWidth(label)) / 2;
        ctx.drawText(mc.textRenderer, label, tx, y + (h - 8) / 2, Draw.COL_TEXT, true);
    }
}

package dev.tiffany.module;

import dev.tiffany.Tiffany;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class CoordsModule extends Module {
    private static final int X = 6, Y = 30, PAD = 4, LINE = 10;

    public CoordsModule() { super("Coordinates", Category.HUD); enabled = true; }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        String xyz = String.format("XYZ: %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
        String dir = "Facing: " + mc.player.getHorizontalFacing().asString();
        int w = Math.max(mc.textRenderer.getWidth(xyz), mc.textRenderer.getWidth(dir));
        Draw.box(ctx, X, Y, w + PAD * 2, LINE * 2 + PAD * 2, Tiffany.THEME.accent(2));
        ctx.drawText(mc.textRenderer, xyz, X + PAD, Y + PAD, Draw.COL_TEXT, true);
        ctx.drawText(mc.textRenderer, dir, X + PAD, Y + PAD + LINE, Draw.COL_DIM, true);
    }
}

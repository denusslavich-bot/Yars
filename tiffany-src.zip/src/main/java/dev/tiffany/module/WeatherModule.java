package dev.tiffany.module;

import net.minecraft.client.MinecraftClient;

public class WeatherModule extends Module {
    public WeatherModule() { super("ClearWeather", Category.WORLD); }

    @Override
    public void tick(MinecraftClient mc) {
        if (!enabled || mc.world == null) return;
        mc.world.setRainGradient(0f);
        mc.world.setThunderGradient(0f);
    }
}

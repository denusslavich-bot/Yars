package dev.tiffany.module;

import dev.tiffany.Tiffany;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class PotionHudModule extends Module {
    private static final int X = 6, Y = 90, PAD = 4, LINE = 11, TICKS_PER_SEC = 20;

    public PotionHudModule() { super("PotionHUD", Category.HUD); }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        int y = Y, i = 0;
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            if (e.getEffectType() == StatusEffects.NIGHT_VISION && Tiffany.FULLBRIGHT.enabled) continue;
            String name = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1);
            int sec = e.getDuration() / TICKS_PER_SEC;
            String time = e.isInfinite() ? "inf" : String.format("%d:%02d", sec / 60, sec % 60);
            String line = name + "  " + time;
            int w = mc.textRenderer.getWidth(line);
            Draw.box(ctx, X, y, w + PAD * 2, LINE + PAD, Tiffany.THEME.accent(i++));
            ctx.drawText(mc.textRenderer, line, X + PAD, y + PAD, Draw.COL_TEXT, true);
            y += LINE + PAD + 2;
        }
    }
}

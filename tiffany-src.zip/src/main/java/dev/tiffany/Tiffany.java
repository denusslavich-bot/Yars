package dev.tiffany;

import dev.tiffany.gui.ClickGui;
import dev.tiffany.module.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class Tiffany implements ClientModInitializer {
    // ===== CONFIG =====
    public static final int KEY_OPEN_GUI = GLFW.GLFW_KEY_RIGHT_SHIFT;
    public static final int KEY_ZOOM     = GLFW.GLFW_KEY_C;
    // ==================

    public static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("tiffany", "main"));
    public static KeyBinding openKey, zoomKey;

    public static final ZoomModule ZOOM = new ZoomModule();
    public static final TimeModule TIME = new TimeModule();
    public static final WeatherModule WEATHER = new WeatherModule();
    public static final FullbrightModule FULLBRIGHT = new FullbrightModule();
    public static final FovModule FOV = new FovModule();
    public static final WatermarkModule WATERMARK = new WatermarkModule();
    public static final ArrayListModule ARRAYLIST = new ArrayListModule();
    public static final KeystrokesModule KEYSTROKES = new KeystrokesModule();
    public static final CoordsModule COORDS = new CoordsModule();
    public static final InfoModule INFO = new InfoModule();
    public static final PotionHudModule POTIONS = new PotionHudModule();
    public static final ArmorHudModule ARMOR = new ArmorHudModule();
    public static final TargetHudModule TARGET = new TargetHudModule();
    public static final ThemeModule THEME = new ThemeModule();

    public static final List<Module> MODULES = List.of(
            ZOOM, TIME, WEATHER, FULLBRIGHT, FOV,
            WATERMARK, ARRAYLIST, KEYSTROKES, COORDS, INFO, POTIONS, ARMOR, TARGET, THEME);

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.tiffany.gui", InputUtil.Type.KEYSYM, KEY_OPEN_GUI, CATEGORY));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.tiffany.zoom", InputUtil.Type.KEYSYM, KEY_ZOOM, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.wasPressed()) mc.setScreen(new ClickGui());
            if (mc.world == null) return;
            for (Module m : MODULES) m.tick(mc);
        });

        HudElementRegistry.addLast(Identifier.of("tiffany", "hud"), (ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden) return;
            for (Module m : MODULES) if (m.enabled) m.render(ctx, mc);
        });
    }
}

package dev.tiffany.module;

public enum Category {
    RENDER("Render"), WORLD("World"), HUD("HUD");

    public final String label;
    Category(String label) { this.label = label; }
}

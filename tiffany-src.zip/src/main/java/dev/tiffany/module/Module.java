package dev.tiffany.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final Category category;
    public boolean enabled;
    public boolean expanded;
    public final List<Setting> settings = new ArrayList<>();

    protected Module(String name, Category category) { this.name = name; this.category = category; }

    protected Setting add(String n, double min, double max, double def) {
        Setting s = new Setting(n, min, max, def);
        settings.add(s);
        return s;
    }

    public void tick(MinecraftClient mc) {}
    public void render(DrawContext ctx, MinecraftClient mc) {}
}

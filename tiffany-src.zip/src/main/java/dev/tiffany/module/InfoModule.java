package dev.tiffany.module;

import dev.tiffany.Tiffany;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

public class InfoModule extends Module {
    private static final int X = 6, Y = 58, PAD = 4, LINE = 10;
    private static final double TICKS_PER_SEC = 20.0, SMOOTH = 0.2;

    private double lastX, lastZ, bps;
    private boolean hasLast;

    public InfoModule() { super("Info", Category.HUD); enabled = true; }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.player == null) { hasLast = false; return; }
        if (hasLast) {
            double d = Math.hypot(mc.player.getX() - lastX, mc.player.getZ() - lastZ) * TICKS_PER_SEC;
            bps += (d - bps) * SMOOTH;
        }
        lastX = mc.player.getX(); lastZ = mc.player.getZ(); hasLast = true;
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        String a = "FPS: " + mc.getCurrentFps() + "   Ping: " + ping + "ms";
        String b = String.format("Speed: %.1f b/s", bps);
        int w = Math.max(mc.textRenderer.getWidth(a), mc.textRenderer.getWidth(b));
        Draw.box(ctx, X, Y, w + PAD * 2, LINE * 2 + PAD * 2, Tiffany.THEME.accent(4));
        ctx.drawText(mc.textRenderer, a, X + PAD, Y + PAD, Draw.COL_TEXT, true);
        ctx.drawText(mc.textRenderer, b, X + PAD, Y + PAD + LINE, Draw.COL_DIM, true);
    }
}

package dev.tiffany.module;

import net.minecraft.util.math.MathHelper;

public class ThemeModule extends Module {
    private static final double CYCLE_MS = 4000.0;
    private static final float SATURATION = 0.75f, BRIGHTNESS = 1f, INDEX_SHIFT = 0.05f;

    public final Setting hue     = add("Hue", 0, 360, 270);
    public final Setting rainbow = add("Rainbow", 0, 1, 0); // >0.5 = on
    public final Setting speed   = add("Speed", 1, 10, 3);

    public ThemeModule() { super("Theme", Category.HUD); enabled = true; }

    public int accent(int index) {
        float h = rainbow.value > 0.5
                ? (float) (((System.currentTimeMillis() * speed.value / CYCLE_MS) + index * INDEX_SHIFT) % 1.0)
                : (float) (hue.value / 360.0);
        return 0xFF000000 | MathHelper.hsvToRgb(h, SATURATION, BRIGHTNESS);
    }
}

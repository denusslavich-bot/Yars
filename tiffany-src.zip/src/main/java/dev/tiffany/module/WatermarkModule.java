package dev.tiffany.module;

import dev.tiffany.Tiffany;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class WatermarkModule extends Module {
    private static final int X = 6, Y = 6, PAD = 4;

    public WatermarkModule() { super("Watermark", Category.HUD); enabled = true; }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc) {
        String text = "Tiffany | " + mc.getCurrentFps() + " fps";
        int w = mc.textRenderer.getWidth(text);
        Draw.box(ctx, X, Y, w + PAD * 2, 9 + PAD * 2, Tiffany.THEME.accent(0));
        ctx.drawText(mc.textRenderer, text, X + PAD, Y + PAD + 1, Draw.COL_TEXT, true);
    }
}

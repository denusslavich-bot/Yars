package dev.tiffany.module;

import dev.tiffany.Tiffany;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.Comparator;
import java.util.List;

public class ArrayListModule extends Module {
    private static final int MARGIN = 4, PAD = 3, ROW_H = 12;

    public ArrayListModule() { super("ArrayList", Category.HUD); enabled = true; }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc) {
        List<Module> active = Tiffany.MODULES.stream()
                .filter(m -> m.enabled && m.category != Category.HUD)
                .sorted(Comparator.comparingInt((Module m) -> mc.textRenderer.getWidth(m.name)).reversed())
                .toList();
        int sw = ctx.getScaledWindowWidth();
        int y = MARGIN, i = 0;
        for (Module m : active) {
            int accent = Tiffany.THEME.accent(i++);
            int w = mc.textRenderer.getWidth(m.name);
            int x1 = sw - MARGIN - w - PAD * 2;
            ctx.fill(x1, y, sw - MARGIN, y + ROW_H, Draw.COL_BG);
            ctx.fill(sw - MARGIN - 1, y, sw - MARGIN, y + ROW_H, accent);
            ctx.drawText(mc.textRenderer, m.name, x1 + PAD, y + 2, accent, true);
            y += ROW_H;
        }
    }
}

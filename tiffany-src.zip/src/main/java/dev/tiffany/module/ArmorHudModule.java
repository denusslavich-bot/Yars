package dev.tiffany.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorHudModule extends Module {
    private static final int ICON = 18, MARGIN_RIGHT = 24, PAD = 2;
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };

    public ArmorHudModule() { super("ArmorHUD", Category.HUD); }

    @Override
    public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        int x = ctx.getScaledWindowWidth() - MARGIN_RIGHT;
        int y = ctx.getScaledWindowHeight() / 2 - ICON * 2;
        for (EquipmentSlot slot : SLOTS) {
            ItemStack s = mc.player.getEquippedStack(slot);
            ctx.fill(x - PAD, y - PAD, x + ICON - PAD, y + ICON - PAD, Draw.COL_BG);
            if (!s.isEmpty()) {
                ctx.drawItem(s, x, y);
                ctx.drawStackOverlay(mc.textRenderer, s, x, y);
            }
            y += ICON + PAD;
        }
    }
}

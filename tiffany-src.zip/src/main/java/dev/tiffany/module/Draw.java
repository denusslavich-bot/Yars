package dev.tiffany.module;

import net.minecraft.client.gui.DrawContext;

public final class Draw {
    public static final int COL_BG = 0xB0121218, COL_TEXT = 0xFFFFFFFF, COL_DIM = 0xFFA0A0B0;

    private Draw() {}

    /** Dark box with accent line on top. */
    public static void box(DrawContext ctx, int x, int y, int w, int h, int accent) {
        ctx.fill(x, y, x + w, y + h, COL_BG);
        ctx.fill(x, y, x + w, y + 1, accent);
    }

    public static int alpha(int argb, int a) { return (argb & 0x00FFFFFF) | (a << 24); }
}

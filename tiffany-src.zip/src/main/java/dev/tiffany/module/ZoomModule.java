package dev.tiffany.module;

import dev.tiffany.Tiffany;
import net.minecraft.client.MinecraftClient;

public class ZoomModule extends Module {
    private static final double SMOOTH_STEP = 0.25;

    public final Setting factor = add("Factor", 1.5, 10.0, 4.0);
    public final Setting smooth = add("Smooth", 0.0, 1.0, 1.0); // >0.5 = smooth
    private double current = 1.0;

    public ZoomModule() { super("Zoom", Category.RENDER); enabled = true; }

    @Override
    public void tick(MinecraftClient mc) {
        double target = (enabled && Tiffany.zoomKey.isPressed()) ? factor.value : 1.0;
        if (smooth.value > 0.5) current += (target - current) * SMOOTH_STEP;
        else current = target;
        if (Math.abs(current - target) < 0.001) current = target;
    }

    public float apply(float fov) { return (float) (fov / current); }
}

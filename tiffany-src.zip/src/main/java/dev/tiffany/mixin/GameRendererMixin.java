package dev.tiffany.mixin;

import dev.tiffany.Tiffany;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void tiffany$fov(Camera camera, float tickProgress, boolean changingFov,
                             CallbackInfoReturnable<Float> cir) {
        float fov = Tiffany.FOV.apply(cir.getReturnValueF());
        cir.setReturnValue(Tiffany.ZOOM.apply(fov));
    }
}
